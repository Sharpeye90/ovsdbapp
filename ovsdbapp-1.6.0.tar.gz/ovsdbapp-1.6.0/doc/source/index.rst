.. the main title comes from README.rst

.. include:: ../../README.rst

----

.. toctree::
   :maxdepth: 2

   install/index
   user/index
   contributor/index

.. only:: html

   .. rubric:: Indices and tables

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
